﻿namespace InventoryService.Domain.Models
{
    public class InventoryUpdateResult
    {
        public int InventoryItemId { get; set; }
        public bool Success { get; set; }
    }
}
